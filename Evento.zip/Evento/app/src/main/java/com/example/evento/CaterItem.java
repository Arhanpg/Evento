package com.example.evento;

public class CaterItem {
    public String itemName;
    public String price;

    public CaterItem() {}

    public CaterItem(String itemName, String price) {
        this.itemName = itemName;
        this.price = price;
    }
}