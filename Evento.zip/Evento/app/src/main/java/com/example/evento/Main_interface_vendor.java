package com.example.evento;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class Main_interface_vendor extends AppCompatActivity {

    private TextView tvWelcome;
    private RecyclerView recyclerView;
    private BookingAdapter adapter;
    private List<BookingModel> bookingList = new ArrayList<>();
    private DatabaseReference bookingsRef;
    private String vendorName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_interface_vendor);

        // 1) Intent extra
        vendorName = getIntent().getStringExtra("company_name");
        if (vendorName == null || vendorName.isEmpty()) {
            vendorName = "Vendor";
        }

        // 2) Bind views
        tvWelcome   = findViewById(R.id.textView34);
        recyclerView= findViewById(R.id.recyclerView);

        // 3) Welcome text
        tvWelcome.setText("Welcome " + vendorName + " !");

        // 4) RecyclerView setup
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BookingAdapter(bookingList);
        recyclerView.setAdapter(adapter);

        // 5) Firebase reference
        bookingsRef = FirebaseDatabase.getInstance()
                .getReference("Bookings")
                .child(vendorName);

        // 6) Load bookings
        loadBookings();
    }

    private void loadBookings() {
        bookingsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snap) {
                bookingList.clear();
                if (!snap.exists()) {
                    Toast.makeText(
                            Main_interface_vendor.this,
                            "No bookings found for " + vendorName,
                            Toast.LENGTH_SHORT
                    ).show();
                    adapter.notifyDataSetChanged();
                    return;
                }

                for (DataSnapshot child : snap.getChildren()) {
                    String custName = child.getKey();
                    if (custName == null) continue;

                    String phone = getValueSafe(child, "customer_phone");
                    String date = getValueSafe(child, "date");
                    String time = getValueSafe(child, "time");
                    String amount = getValueSafe(child, "amount");
                    String items = getValueSafe(child, "items");

                    bookingList.add(new BookingModel(
                            custName,
                            phone,
                            date,
                            time,
                            amount,
                            items
                    ));
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError err) {
                Toast.makeText(
                        Main_interface_vendor.this,
                        "Error loading bookings: " + err.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }

    // Helper method for safe value retrieval
    private String getValueSafe(DataSnapshot snapshot, String path) {
        if (snapshot.child(path).exists()) {
            Object value = snapshot.child(path).getValue();
            return value != null ? value.toString() : "";
        }
        return "";
    }
}