package com.example.evento;

public class BookingModel {
    public String customerName;
    public String customerPhone;
    public String date;
    public String time;
    public String amount;
    public String items;

    public BookingModel() { }

    public BookingModel(
            String customerName,
            String customerPhone,
            String date,
            String time,
            String amount,
            String items
    ) {
        this.customerName  = customerName;
        this.customerPhone = customerPhone;
        this.date          = date;
        this.time          = time;
        this.amount        = amount;
        this.items         = items != null ? items : "";
    }
}