package com.example.evento;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class BookingAdapter extends RecyclerView.Adapter<BookingAdapter.ViewHolder> {

    private final List<BookingModel> list;

    public BookingAdapter(List<BookingModel> list) {
        this.list = list;
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custom_recycler9, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int pos) {
        BookingModel b = list.get(pos);
        holder.name.setText(b.customerName);
        holder.phone.setText(b.customerPhone);
        holder.date.setText(b.date);
        holder.time.setText(b.time);
        holder.amount.setText(b.amount);

        if(b.items == null || b.items.isEmpty()) {
            holder.items.setVisibility(View.GONE);
        } else {
            holder.items.setVisibility(View.VISIBLE);
            holder.items.setText(b.items);
        }
    }

    @Override public int getItemCount() { return list.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, phone, date, time, amount, items;
        ViewHolder(@NonNull View v) {
            super(v);
            name   = v.findViewById(R.id.textView6);
            phone  = v.findViewById(R.id.textView7);
            date   = v.findViewById(R.id.textView10);
            time   = v.findViewById(R.id.textView14);
            amount = v.findViewById(R.id.textView15);
            items  = v.findViewById(R.id.textView33);
        }
    }
}