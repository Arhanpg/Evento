package com.example.evento;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Vendor_details_upload extends AppCompatActivity {
    private EditText companyName, userName, phoneNumber, location, venueCapacity, venueRent;
    private Spinner serviceSpinner;
    private Button submitBtn, alreadyUserBtn;
    private EditText alreadyUserInput;
    private String selectedService = "";
    private DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            androidx.activity.EdgeToEdge.enable(this);
        }
        setContentView(R.layout.activity_vendor_details_upload);

        // 1) Firebase ref
        databaseRef = FirebaseDatabase.getInstance().getReference("Vendors");

        // 2) Bind views
        companyName     = findViewById(R.id.company_name);
        userName        = findViewById(R.id.your_name);
        phoneNumber     = findViewById(R.id.phone_number);
        location        = findViewById(R.id.location);
        venueCapacity   = findViewById(R.id.venue_capacity);
        venueRent       = findViewById(R.id.venue_rent);
        serviceSpinner  = findViewById(R.id.service_spinner);
        submitBtn       = findViewById(R.id.submitBtn);

        alreadyUserInput= findViewById(R.id.editTextText);
        alreadyUserBtn  = findViewById(R.id.button);

        // 3) Spinner setup
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                new String[]{"Select your service", "Venues", "Caterers", "Decorators"}
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        serviceSpinner.setAdapter(adapter);
        serviceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                selectedService = p.getItemAtPosition(pos).toString();
                if (pos == 0) {
                    venueCapacity.setVisibility(View.GONE);
                    venueRent.setVisibility(View.GONE);
                    selectedService = "";
                } else if ("Venues".equals(selectedService)) {
                    venueCapacity.setVisibility(View.VISIBLE);
                    venueRent.setVisibility(View.VISIBLE);
                } else {
                    venueCapacity.setVisibility(View.GONE);
                    venueRent.setVisibility(View.GONE);
                }
            }
            @Override public void onNothingSelected(AdapterView<?> p) { selectedService = ""; }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // 4) Click handlers
        submitBtn.setOnClickListener(v -> saveVendorDetails());
        alreadyUserBtn.setOnClickListener(v -> checkVendorExists());
    }

    private void saveVendorDetails() {
        String company = companyName.getText().toString().trim();
        String name    = userName.getText().toString().trim();
        String phone   = phoneNumber.getText().toString().trim();
        String loc     = location.getText().toString().trim();
        String cap     = venueCapacity.getText().toString().trim();
        String rent    = venueRent.getText().toString().trim();

        if (company.isEmpty()||name.isEmpty()||phone.isEmpty()||loc.isEmpty()||selectedService.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        VendorModel vendor = new VendorModel(
                company, name, phone, loc,
                cap.isEmpty() ? "N/A" : cap,
                rent.isEmpty()? "N/A" : rent,
                selectedService
        );

        databaseRef.child(company)
                .setValue(vendor)
                .addOnSuccessListener(u -> {
                    Toast.makeText(this, "Vendor registered!", Toast.LENGTH_SHORT).show();
                    clearFields();
                    Intent i = new Intent(this, Image_upload.class);
                    i.putExtra("vendor_id", company);
                    i.putExtra("service_provided", selectedService);
                    startActivity(i);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show()
                );
    }

    private void checkVendorExists() {
        String inputCompany = alreadyUserInput.getText().toString().trim();
        if (inputCompany.isEmpty()) {
            Toast.makeText(this, "Enter company name", Toast.LENGTH_SHORT).show();
            return;
        }

        databaseRef.child(inputCompany)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot snap) {
                        if (snap.exists()) {
                            Intent i = new Intent(Vendor_details_upload.this, Main_interface_vendor.class);
                            i.putExtra("company_name", inputCompany);
                            startActivity(i);
                        } else {
                            Toast.makeText(
                                    Vendor_details_upload.this,
                                    "Vendor does not exist.",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }
                    @Override public void onCancelled(DatabaseError err) {
                        Toast.makeText(
                                Vendor_details_upload.this,
                                "Error checking vendor",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });
    }

    private void clearFields() {
        companyName.setText("");
        userName.setText("");
        phoneNumber.setText("");
        location.setText("");
        venueCapacity.setText("");
        venueRent.setText("");
        serviceSpinner.setSelection(0);
    }

    // VendorModel inner class
    public static class VendorModel {
        public String companyName, userName, phone, location, capacity, rent, service;
        public VendorModel() { }
        public VendorModel(
                String companyName,
                String userName,
                String phone,
                String location,
                String capacity,
                String rent,
                String service
        ) {
            this.companyName = companyName;
            this.userName    = userName;
            this.phone       = phone;
            this.location    = location;
            this.capacity    = capacity;
            this.rent        = rent;
            this.service     = service;
        }
    }
}
