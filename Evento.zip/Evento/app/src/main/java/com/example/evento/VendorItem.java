package com.example.evento;

import java.io.Serializable;

public class VendorItem implements Serializable {
    private String name;
    private double price;
    private String description;

    // Required for Firebase
    public VendorItem() {}

    public VendorItem(String name, String price, String description) {
        this.name = name;
        try {
            this.price = Double.parseDouble(price);
        } catch (NumberFormatException e) {
            this.price = 0.0;
        }
        this.description = description;
    }

    // Optional: Another constructor if you still need it
    public VendorItem(String name, String price) {
        this(name, price, "");
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }
}
