package com.example.evento;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class caterer_payment extends AppCompatActivity implements PaymentResultListener {

    private static final String TAG = caterer_payment.class.getSimpleName();
    private RecyclerView recyclerView1, recyclerView2;
    private TextView perPlateCostText;
    private EditText guestCountEdit, nameEdit, phoneEdit, dateEdit, timeEdit;
    private Button payButton;

    private ArrayList<CaterItem> availableItems = new ArrayList<>();
    private ArrayList<CaterItem> selectedItems = new ArrayList<>();

    private AvailableAdapter availableAdapter;
    private SelectedAdapter selectedAdapter;

    private int perPlateCost = 0;
    private String vendorName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caterer_payment);

        // 1) Init views
        recyclerView1 = findViewById(R.id.recyclerView1);
        recyclerView2 = findViewById(R.id.recyclerView2);
        perPlateCostText = findViewById(R.id.textView29);
        guestCountEdit = findViewById(R.id.editTextNumberSigned);
        nameEdit = findViewById(R.id.editTextText14);
        phoneEdit = findViewById(R.id.editTextPhone);
        dateEdit = findViewById(R.id.editTextDate2);
        timeEdit = findViewById(R.id.editTextTime);
        payButton = findViewById(R.id.button17);

        // 2) Setup RecyclerViews
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));
        availableAdapter = new AvailableAdapter();
        selectedAdapter = new SelectedAdapter();
        recyclerView1.setAdapter(availableAdapter);
        recyclerView2.setAdapter(selectedAdapter);

        // 3) Initialize per‑plate display
        perPlateCostText.setText("Per plate cost: ₹0");

        // 4) Grab vendor name & item list from Intent
        vendorName = getIntent().getStringExtra("Vendor_name");
        ArrayList<VendorItem> itemsFromIntent =
                (ArrayList<VendorItem>) getIntent().getSerializableExtra("ItemList");

        // 5) Populate availableItems from passed list
        if (itemsFromIntent != null) {
            for (VendorItem vi : itemsFromIntent) {
                availableItems.add(new CaterItem(vi.getName(), (int)vi.getPrice()));
            }
            availableAdapter.notifyDataSetChanged();
        }

        // 6) Razorpay preload
        Checkout.preload(getApplicationContext());

        // 7) Pay button
        payButton.setOnClickListener(v -> startPayment());
    }

    private void startPayment() {
        String custName = nameEdit.getText().toString().trim();
        String phone    = phoneEdit.getText().toString().trim();
        String guestsS  = guestCountEdit.getText().toString().trim();
        String date     = dateEdit.getText().toString().trim();
        String time     = timeEdit.getText().toString().trim();

        if (custName.isEmpty() || phone.isEmpty() || guestsS.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        if (selectedItems.isEmpty()) {
            Toast.makeText(this, "Please select at least one item", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int guests      = Integer.parseInt(guestsS);
            int totalAmount = perPlateCost * guests;
            payButton.setText("Pay: ₹" + totalAmount);

            Checkout checkout = new Checkout();
            checkout.setKeyID("rzp_test_g9coO6mLvqk7WR");

            JSONObject options = new JSONObject();
            options.put("name", vendorName);
            options.put("description", "Food Order Payment");
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");
            options.put("currency", "INR");
            options.put("amount", totalAmount * 100);

            JSONObject prefill = new JSONObject();
            prefill.put("email", "customer@example.com");
            prefill.put("contact", phone);
            prefill.put("name", custName);
            options.put("prefill", prefill);

            checkout.open(this, options);
        } catch (Exception e) {
            Toast.makeText(this, "Payment error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e(TAG, "Payment error", e);
        }
    }

    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        saveBookingToFirebase();
        Toast.makeText(this, "Payment Successful! ID: " + razorpayPaymentID, Toast.LENGTH_SHORT).show();
        clearForm();
    }

    @Override
    public void onPaymentError(int code, String response) {
        Toast.makeText(this, "Payment failed: " + response, Toast.LENGTH_SHORT).show();
    }

    private void saveBookingToFirebase() {
        try {
            String custName = nameEdit.getText().toString().trim();
            String phone    = phoneEdit.getText().toString().trim();
            int guests      = Integer.parseInt(guestCountEdit.getText().toString().trim());
            int totalAmount = perPlateCost * guests;

            DatabaseReference ref = FirebaseDatabase.getInstance()
                    .getReference("Bookings")
                    .child(vendorName)
                    .child(custName);

            Map<String,Object> booking = new HashMap<>();
            booking.put("customer_name",   custName);
            booking.put("customer_phone",  phone);
            booking.put("amount",          totalAmount);
            booking.put("date",            dateEdit.getText().toString().trim());
            booking.put("time",            timeEdit.getText().toString().trim());
            booking.put("status",          "Paid");
            booking.put("items",           getSelectedItemsNames());

            ref.setValue(booking)
                    .addOnSuccessListener(a -> Log.d(TAG, "Booking saved"))
                    .addOnFailureListener(e -> Log.e(TAG, "Save error", e));
        } catch (Exception e) {
            Log.e(TAG, "Error saving booking", e);
        }
    }

    private String getSelectedItemsNames() {
        StringBuilder sb = new StringBuilder();
        for (CaterItem ci : selectedItems) {
            sb.append(ci.name).append(", ");
        }
        if (sb.length()>2) sb.setLength(sb.length()-2);
        return sb.toString();
    }

    private void clearForm() {
        nameEdit.setText("");
        phoneEdit.setText("");
        guestCountEdit.setText("");
        dateEdit.setText("");
        timeEdit.setText("");

        availableItems.addAll(selectedItems);
        selectedItems.clear();
        perPlateCost = 0;
        perPlateCostText.setText("Per plate cost: ₹0");

        availableAdapter.notifyDataSetChanged();
        selectedAdapter.notifyDataSetChanged();
    }

    // ---- Inner classes ----

    class CaterItem {
        String name; int price;
        CaterItem(String n,int p){ name=n; price=p; }
    }

    class AvailableAdapter extends RecyclerView.Adapter<AvailableAdapter.ViewHolder> {
        @NonNull @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent,int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.custom_recycler7, parent, false);
            return new ViewHolder(v);
        }
        @Override public void onBindViewHolder(@NonNull ViewHolder h,int i) {
            CaterItem item = availableItems.get(i);
            h.name.setText(item.name);
            h.price.setText("₹"+item.price);
            h.add.setOnClickListener(v -> {
                selectedItems.add(item);
                availableItems.remove(i);
                perPlateCost += item.price;
                perPlateCostText.setText("Per plate cost: ₹"+perPlateCost);
                notifyDataSetChanged();
                selectedAdapter.notifyDataSetChanged();
            });
        }
        @Override public int getItemCount(){ return availableItems.size(); }
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView name, price; ImageView add;
            ViewHolder(View v) {
                super(v);
                name  = v.findViewById(R.id.textView25);
                price = v.findViewById(R.id.textView26);
                add   = v.findViewById(R.id.imageView12);
            }
        }
    }

    class SelectedAdapter extends RecyclerView.Adapter<SelectedAdapter.ViewHolder> {
        @NonNull @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup p,int vt){
            View v=LayoutInflater.from(p.getContext())
                    .inflate(R.layout.custom_recycler8,p,false);
            return new ViewHolder(v);
        }
        @Override public void onBindViewHolder(@NonNull ViewHolder h,int i){
            CaterItem item=selectedItems.get(i);
            h.name.setText(item.name);
            h.price.setText("₹"+item.price);
            h.remove.setOnClickListener(v->{
                availableItems.add(item);
                selectedItems.remove(i);
                perPlateCost -= item.price;
                perPlateCostText.setText("Per plate cost: ₹"+perPlateCost);
                notifyDataSetChanged();
                availableAdapter.notifyDataSetChanged();
            });
        }
        @Override public int getItemCount(){return selectedItems.size();}
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView name, price; ImageView remove;
            ViewHolder(View v){
                super(v);
                name   = v.findViewById(R.id.textView27);
                price  = v.findViewById(R.id.textView28);
                remove = v.findViewById(R.id.imageView16);
            }
        }
    }
}
